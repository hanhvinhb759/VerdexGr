import { t as LoginPage } from "./account-pages-BS_GSM2g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dang-nhap-q31Zwfac.js
var SplitComponent = LoginPage;
//#endregion
export { SplitComponent as component };
