import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-B1f16EgT.js
var PILLARS = [
	{
		id: "P",
		name: "Green Packaging",
		vi: "Đóng gói xanh",
		inOgs: true
	},
	{
		id: "T",
		name: "Green Transportation",
		vi: "Vận chuyển xanh",
		inOgs: true
	},
	{
		id: "R",
		name: "Reverse Logistics",
		vi: "Logistics ngược",
		inOgs: true
	},
	{
		id: "TGS",
		name: "Transparency",
		vi: "Minh bạch truyền thông",
		inOgs: false
	}
];
var CRITERIA = [
	{
		id: "p1",
		pillar: "P",
		name: "Tỷ lệ vật liệu tái chế hoặc tái tạo",
		score: 90,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Giữ tỷ lệ tái chế và lưu hóa đơn nhà cung cấp theo kỳ."
	},
	{
		id: "p2",
		pillar: "P",
		name: "Mức giảm nhựa nguyên sinh",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Đặt mốc giảm nhựa nguyên sinh so với kỳ gốc 24 tháng."
	},
	{
		id: "p3",
		pillar: "P",
		name: "Hệ số khoảng trống bao bì",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Chuẩn hóa kích thước thùng và giảm vật liệu chèn."
	},
	{
		id: "p4",
		pillar: "P",
		name: "Bao bì tái sử dụng hoặc chuẩn hóa",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Mở vòng tuần hoàn thùng cho nhóm đơn lặp lại."
	},
	{
		id: "p5",
		pillar: "P",
		name: "Kiểm soát vật liệu hạn chế",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Lưu bảng thành phần và cam kết nhà cung cấp."
	},
	{
		id: "t1",
		pillar: "T",
		name: "Cơ cấu phương thức vận tải",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Dịch các tuyến phù hợp từ đường bộ sang đường sắt hoặc thủy."
	},
	{
		id: "t2",
		pillar: "T",
		name: "Tỷ lệ phương tiện phát thải thấp",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Ghi nhận tỷ lệ xe đạt chuẩn khí thải cao hơn hoặc dùng điện."
	},
	{
		id: "t3",
		pillar: "T",
		name: "Hệ số chất tải và chạy rỗng",
		score: 50,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Đo tỷ lệ chạy rỗng theo tuyến và ghép đơn chiều về."
	},
	{
		id: "t4",
		pillar: "T",
		name: "Gom hàng và tối ưu tuyến",
		score: 70,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Cố định cửa sổ gom đơn nội thành trước khi xuất bến."
	},
	{
		id: "t5",
		pillar: "T",
		name: "Cường độ nhiên liệu",
		score: 50,
		status: "implemented",
		verify: "evidence",
		evidence: false,
		days: 12,
		clash: false,
		action: "Nhập km, tấn và loại phương tiện. Chưa công bố phát thải đã kiểm toán."
	},
	{
		id: "r1",
		pillar: "R",
		name: "Phạm vi chương trình thu hồi",
		score: 50,
		status: "implemented",
		verify: "evidence",
		evidence: true,
		days: 12,
		clash: false,
		action: "Mở thu hồi cho nhóm đơn thương mại điện tử còn thiếu."
	},
	{
		id: "r2",
		pillar: "R",
		name: "Tỷ lệ tiếp nhận trên đơn đủ điều kiện",
		score: 50,
		status: "implemented",
		verify: "evidence",
		evidence: true,
		days: 12,
		clash: false,
		action: "Công bố điểm trả hàng và đo tỷ lệ đơn được nhận lại."
	},
	{
		id: "r3",
		pillar: "R",
		name: "Cơ cấu tái sử dụng, tái chế, chôn lấp",
		score: 55,
		status: "implemented",
		verify: "evidence",
		evidence: true,
		days: 12,
		clash: false,
		action: "Tách sản lượng tái sử dụng khỏi phần đem chôn lấp."
	},
	{
		id: "r4",
		pillar: "R",
		name: "Khả năng tiếp cận điểm trả",
		score: 50,
		status: "implemented",
		verify: "evidence",
		evidence: true,
		days: 12,
		clash: false,
		action: "Thêm điểm trả trong vùng giao hàng hiện có."
	},
	{
		id: "r5",
		pillar: "R",
		name: "Hồ sơ đối tác xử lý",
		score: 50,
		status: "implemented",
		verify: "evidence",
		evidence: false,
		days: 12,
		clash: false,
		action: "Xin tệp đối soát từ đơn vị thu hồi để lên mức cross-checked."
	},
	{
		id: "g1",
		pillar: "TGS",
		name: "Tuyên bố xanh có minh chứng",
		score: 100,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Giữ liên kết từ mỗi tuyên bố tới minh chứng đã được phép công khai."
	},
	{
		id: "g2",
		pillar: "TGS",
		name: "Nhất quán giữa công bố và vận hành",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: true,
		action: "Rà tuyên bố đang cao hơn dữ liệu vận chuyển và thu hồi."
	},
	{
		id: "g3",
		pillar: "TGS",
		name: "Khách hàng tiếp cận được bằng chứng",
		score: 75,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Đưa tóm tắt dễ hiểu lên hồ sơ công khai, không mở toàn văn chứng từ."
	},
	{
		id: "g4",
		pillar: "TGS",
		name: "Tuổi thông tin công bố",
		score: 100,
		status: "implemented",
		verify: "cross",
		evidence: true,
		days: 12,
		clash: false,
		action: "Cập nhật ngày công bố mỗi khi hồ sơ vận hành đổi."
	},
	{
		id: "g5",
		pillar: "TGS",
		name: "Hạn chế tuyên bố không có cơ sở",
		score: 70,
		status: "implemented",
		verify: "evidence",
		evidence: true,
		days: 12,
		clash: false,
		action: "Gỡ các câu tuyệt đối như xanh hoàn toàn khi coverage hoặc confidence chưa đủ."
	}
];
var PLANS = [
	{
		id: "trial",
		name: "Free Trial",
		price: "0 đồng · 45 ngày",
		points: [
			"Tạo hồ sơ và tải minh chứng",
			"Xem OGS nếu đủ hai trụ",
			"Checklist chẩn đoán tối đa năm mục"
		]
	},
	{
		id: "basic",
		name: "Paid Basic",
		price: "Phí thấp theo tháng",
		points: [
			"Theo dõi điểm theo thời gian",
			"Lưu các kỳ đã chốt",
			"Cảnh báo dữ liệu quá hạn"
		]
	},
	{
		id: "standard",
		name: "Paid Standard",
		price: "Phí phân tích",
		points: [
			"Tổng hợp phản hồi khách hàng",
			"Green Perception Gap",
			"Checklist có thứ tự ưu tiên"
		]
	},
	{
		id: "premium",
		name: "Paid Premium",
		price: "Phí báo cáo",
		points: [
			"Báo cáo cho đối tác",
			"Chuẩn bị biến đầu vào kiểu GLEC",
			"Không gồm kiểm toán carbon"
		]
	}
];
var PEERS = [{
	code: "SH-1180",
	name: "Sông Hậu Express",
	segment: "3PL đường bộ và last-mile thương mại điện tử",
	greenScore: 71,
	confidence: 64,
	band: "Limited",
	coverage: "Provisional · 2/3",
	comparable: true,
	note: "Cùng nhóm 3PL. Reverse Logistics chưa đủ dữ liệu nên coverage chưa đầy."
}, {
	code: "CX-0901",
	name: "Cảng Xanh Depot",
	segment: "Kho bãi và depot container",
	greenScore: 58,
	confidence: 44,
	band: "Provisional",
	coverage: "Full · kho bãi",
	comparable: false,
	note: "Khác nhóm hoạt động. Không so sánh Green Score với doanh nghiệp vận tải last-mile."
}];
function seedItems() {
	return Object.fromEntries(CRITERIA.map((item) => [item.id, {
		score: item.score,
		status: item.status,
		verify: item.verify,
		evidence: item.evidence,
		days: item.days,
		clash: item.clash
	}]));
}
/** Tham số prototype. Chưa phải trọng số đã kiểm định thực nghiệm. */
function geometricMean(values) {
	if (values.length === 0) return 0;
	return values.reduce((acc, value) => acc * value, 1) ** (1 / values.length);
}
function greenScore(ogs, tgs) {
	const raw = .85 * ogs + .15 * tgs;
	return Math.min(raw, ogs + 10);
}
function dataConfidence(evidence, consistency, recency, verification) {
	return .2 * evidence + .2 * consistency + .15 * recency + .45 * verification;
}
function confidenceBand(score) {
	if (score >= 70) return "Confirmed";
	if (score >= 50) return "Limited";
	return "Provisional";
}
function gapBand(absGap) {
	if (absGap <= 5) return "Alignment";
	if (absGap <= 15) return "Moderate Gap";
	return "Significant Gap";
}
function round0(value) {
	return Math.round(value);
}
function round1(value) {
	return Math.round(value * 10) / 10;
}
var VERIFY_SCORE = {
	self: 30,
	evidence: 60,
	cross: 80,
	external: 100
};
function recencyScore(days) {
	if (days <= 30) return 100;
	if (days <= 90) return 85;
	if (days <= 180) return 70;
	if (days <= 365) return 50;
	return 25;
}
function mean(values) {
	if (values.length === 0) return 0;
	return values.reduce((sum, value) => sum + value, 0) / values.length;
}
function toneOf(score) {
	if (score === null) return "off";
	if (score >= 75) return "steady";
	if (score >= 60) return "watch";
	return "weak";
}
function buildVerdict(items, perception, history) {
	const rows = CRITERIA.map((criterion) => ({
		...criterion,
		...items[criterion.id]
	}));
	const applicable = rows.filter((row) => row.status !== "na");
	const evidenceRatio = applicable.length === 0 ? 0 : applicable.filter((row) => row.evidence).length / applicable.length * 100;
	const comparable = applicable.filter((row) => row.verify === "cross" || row.verify === "external");
	const clashes = comparable.filter((row) => row.clash).length;
	let consistency = 15;
	if (comparable.length >= 2) {
		if (clashes === 0) consistency = 100;
		else if (clashes === 1) consistency = 80;
		else if (clashes === 2) consistency = 60;
		else consistency = 30;
	}
	const recency = mean(applicable.map((row) => recencyScore(row.days)));
	const verification = mean(applicable.map((row) => VERIFY_SCORE[row.verify]));
	const confidenceExact = dataConfidence(evidenceRatio, consistency, recency, verification);
	const confidence = round0(confidenceExact);
	const pillars = PILLARS.map((pillar) => {
		const inScope = rows.filter((row) => row.pillar === pillar.id).filter((row) => row.status !== "na");
		const insufficient = inScope.some((row) => row.status === "insufficient");
		const notDone = inScope.some((row) => row.status === "not_implemented");
		const implemented = inScope.filter((row) => row.status === "implemented");
		const applicablePillar = inScope.length > 0;
		const eligible = applicablePillar && !insufficient && !notDone && implemented.length > 0;
		const score = eligible ? mean(implemented.map((row) => row.score)) : null;
		const weak = implemented.slice().sort((a, b) => a.score - b.score)[0];
		let status = "Implemented";
		if (!applicablePillar) status = "Not Applicable";
		else if (insufficient) status = "Insufficient Data";
		else if (notDone) status = "Not Implemented";
		const note = !eligible ? "Trụ này chưa đưa vào điểm tổng hợp." : weak ? `${weak.name} đang ở ${round0(weak.score)}.` : "";
		return {
			...pillar,
			score: score === null ? null : round0(score),
			exact: score,
			status,
			eligible,
			applicable: applicablePillar,
			tone: toneOf(score === null ? null : round0(score)),
			note
		};
	});
	const operational = pillars.filter((pillar) => pillar.inOgs && pillar.applicable);
	const eligibleOps = operational.filter((pillar) => pillar.eligible && pillar.exact !== null);
	const ogs = eligibleOps.length >= 2 ? geometricMean(eligibleOps.map((pillar) => pillar.exact)) : null;
	const tgs = pillars.find((pillar) => pillar.id === "TGS")?.exact ?? null;
	const raw = ogs !== null && tgs !== null ? .85 * ogs + .15 * tgs : null;
	const cap = ogs !== null ? ogs + 10 : null;
	const gs = ogs !== null && tgs !== null ? greenScore(ogs, tgs) : null;
	const published = gs === null ? null : round0(gs);
	let coverageKind = "insufficient";
	let coverageLabel = "Insufficient Assessment Scope";
	if (eligibleOps.length >= 2 && eligibleOps.length === operational.length) {
		coverageKind = "full";
		coverageLabel = "Full Applicable Coverage";
	} else if (eligibleOps.length >= 2) {
		coverageKind = "provisional";
		coverageLabel = "Provisional – Incomplete Coverage";
	}
	const coverageDetail = `${eligibleOps.length}/${operational.length} trụ vận hành đủ điều kiện`;
	const gapOfficial = perception.count >= 50 && coverageKind !== "insufficient" && confidence >= 50 && published !== null;
	const gap = published === null ? null : published - round0(perception.score);
	const band = gap === null ? null : gapBand(Math.abs(gap));
	let gapText = "Chưa đủ điều kiện công bố khoảng cách chính thức.";
	if (gapOfficial && gap !== null && band) {
		if (gap < -5) gapText = "Khách hàng cảm nhận xanh hơn dữ liệu. Đây là tín hiệu cần kiểm tra, không phải kết luận greenwashing.";
		else if (gap > 5) gapText = "Điểm dữ liệu cao hơn nhận thức. Vấn đề nằm ở cách công bố, không phải làm hồ sơ trông xanh hơn.";
		else gapText = "Điểm dữ liệu và nhận thức đang gần nhau. Giữ nhịp cập nhật và thu phản hồi.";
	} else if (perception.count < 20) gapText = "Dưới 20 đánh giá hợp lệ. Chưa hiển thị nhận thức như một kết luận.";
	else if (perception.count < 50) gapText = "Nhận thức ở mức tham khảo. Chưa tính Gap chính thức.";
	const weakest = eligibleOps.slice().sort((a, b) => (a.exact ?? 0) - (b.exact ?? 0))[0] ?? null;
	const trend = [...history, ...published === null ? [] : [{
		period: "Hiện tại",
		score: published
	}]];
	const loop = [
		{
			id: "data",
			label: "Dữ liệu",
			state: "done",
			detail: `${applicable.length} tiêu chí đang trong phạm vi áp dụng.`
		},
		{
			id: "check",
			label: "Xác thực",
			state: "done",
			detail: `Validation and Verification đang ở ${round0(verification)}. Chưa có xác minh ngoài nếu số mục externally verified bằng 0.`
		},
		{
			id: "score",
			label: "Green Score",
			state: published === null ? "wait" : "done",
			detail: published === null ? "Chưa đủ hai trụ vận hành để công bố OGS." : `Điểm công bố ${published}, kèm ${coverageLabel}.`
		},
		{
			id: "voice",
			label: "Nhận thức",
			state: perception.count >= 20 ? "done" : "wait",
			detail: `${perception.count} đánh giá. Ngưỡng tham khảo là 20, ngưỡng Gap chính thức là 50.`
		},
		{
			id: "gap",
			label: "Perception Gap",
			state: gapOfficial ? "done" : "wait",
			detail: gapText
		},
		{
			id: "dx",
			label: "Chẩn đoán",
			state: "now",
			detail: weakest ? `${weakest.vi} là trụ vận hành thấp nhất trong phạm vi đã tính.` : "Chưa đủ trụ để chẩn đoán điểm nghẽn."
		},
		{
			id: "act",
			label: "Cải thiện",
			state: "wait",
			detail: "Khuyến nghị lấy từ thư viện gắn với tiêu chí thấp. Đánh dấu đã làm không tự nâng điểm."
		},
		{
			id: "redo",
			label: "Đánh giá lại",
			state: "wait",
			detail: "Chốt kỳ khi muốn lưu điểm hiện tại vào diễn biến."
		}
	];
	return {
		pillars,
		rows,
		ogs,
		ogsLabel: ogs === null ? "—" : String(round1(ogs)),
		rawScore: raw === null ? null : round1(raw),
		cap: cap === null ? null : round1(cap),
		greenScore: published,
		confidence,
		confidenceExact: round1(confidenceExact),
		confidenceBand: confidenceBand(confidence),
		parts: {
			evidence: round0(evidenceRatio),
			consistency: round0(consistency),
			recency: round0(recency),
			verification: round0(verification)
		},
		coverageKind,
		coverageLabel,
		coverageDetail,
		perception: round0(perception.score),
		perceptionExact: round1(perception.score),
		reviewCount: perception.count,
		gap,
		absGap: gap === null ? null : Math.abs(gap),
		gapBand: band,
		gapOfficial,
		gapText,
		weakest,
		trend,
		loop,
		externalCount: applicable.filter((row) => row.verify === "external").length,
		evidenceMissing: applicable.filter((row) => !row.evidence).length
	};
}
function pillarItems(verdict, id) {
	return verdict.rows.filter((row) => row.pillar === id);
}
var profileSeed = {
	name: "An Lá Logistics",
	code: "AL-2048",
	segment: "3PL đường bộ và last-mile thương mại điện tử",
	email: "anla@verdex.vn",
	updated: "12 ngày trước"
};
var perceptionSeed = {
	count: 62,
	score: 74,
	themes: [
		{
			id: "pack",
			label: "Bao bì",
			count: 18
		},
		{
			id: "ship",
			label: "Giao hàng",
			count: 22
		},
		{
			id: "back",
			label: "Thu hồi",
			count: 14
		},
		{
			id: "clear",
			label: "Minh bạch",
			count: 8
		}
	]
};
var historySeed = [
	{
		period: "T4",
		score: 58
	},
	{
		period: "T5",
		score: 59
	},
	{
		period: "T6",
		score: 61
	},
	{
		period: "T7",
		score: 63
	},
	{
		period: "T8",
		score: 64
	}
];
var initial = {
	profile: profileSeed,
	plan: "standard",
	items: seedItems(),
	perception: perceptionSeed,
	history: historySeed,
	done: {}
};
var useVerdex = create((set, get) => ({
	...initial,
	setItem: (id, patch) => set((state) => ({
		items: {
			...state.items,
			[id]: {
				...state.items[id],
				...patch
			}
		},
		profile: {
			...state.profile,
			updated: "vừa cập nhật trong phiên"
		}
	})),
	setPlan: (plan) => set({ plan }),
	setProfile: (patch) => set((state) => ({ profile: {
		...state.profile,
		...patch
	} })),
	addReview: (score, themeId) => set((state) => {
		const count = state.perception.count + 1;
		return { perception: {
			count,
			score: (state.perception.score * state.perception.count + score) / count,
			themes: state.perception.themes.map((theme) => theme.id === themeId ? {
				...theme,
				count: theme.count + 1
			} : theme)
		} };
	}),
	toggleDone: (id) => set((state) => ({ done: {
		...state.done,
		[id]: !state.done[id]
	} })),
	commitPeriod: (period) => {
		const verdict = buildVerdict(get().items, get().perception, get().history);
		if (verdict.greenScore === null) return;
		const label = period.trim() || `Kỳ ${get().history.length + 1}`;
		set((state) => ({ history: [...state.history, {
			period: label,
			score: verdict.greenScore
		}] }));
	},
	reset: () => set({
		...initial,
		items: seedItems(),
		perception: {
			...perceptionSeed,
			themes: perceptionSeed.themes.map((theme) => ({ ...theme }))
		},
		history: [...historySeed],
		done: {}
	})
}));
function useVerdict() {
	return buildVerdict(useVerdex((state) => state.items), useVerdex((state) => state.perception), useVerdex((state) => state.history));
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as a, useVerdict as c, PLANS as i, PEERS as n, pillarItems as o, PILLARS as r, useVerdex as s, CRITERIA as t };
