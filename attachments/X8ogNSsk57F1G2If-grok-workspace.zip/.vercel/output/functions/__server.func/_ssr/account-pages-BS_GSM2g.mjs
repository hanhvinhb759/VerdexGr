import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, b as Link, w as require_jsx_runtime, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, c as useVerdict, i as PLANS, s as useVerdex } from "./utils-B1f16EgT.mjs";
import { t as EnterpriseShell } from "./enterprise-shell-DEfrS-6K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-pages-BS_GSM2g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Center({ title, text, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-slate-50 px-4 py-10 text-slate-900",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-sm font-semibold text-emerald-800",
					children: "Verdex"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-2xl font-semibold tracking-tight",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-6 text-slate-600",
					children: text
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children
				})
			]
		})
	});
}
function LoginPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("anla@verdex.vn");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Center, {
		title: "Đăng nhập",
		text: "Phiên trình diễn, không phải lớp bảo mật. Tài khoản mẫu anla@verdex.vn, mật khẩu verdex.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: (event) => {
				event.preventDefault();
				if (email.trim().toLowerCase() === "anla@verdex.vn" && password === "verdex") {
					sessionStorage.setItem("verdex-session", "enterprise");
					navigate({ to: "/tong-quan" });
					return;
				}
				setError("Sai tài khoản mẫu.");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					value: email,
					onChange: setEmail,
					type: "email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mật khẩu",
					value: password,
					onChange: setPassword,
					type: "password"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-rose-700",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "min-h-11 w-full rounded-xl bg-emerald-700 text-sm font-semibold text-emerald-50",
					children: "Vào bảng doanh nghiệp"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/dang-ky",
			className: "mt-4 inline-flex min-h-11 items-center text-sm font-medium text-slate-700",
			children: "Chưa có hồ sơ"
		})]
	});
}
function RegisterPage() {
	const navigate = useNavigate();
	const setProfile = useVerdex((state) => state.setProfile);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [segment, setSegment] = (0, import_react.useState)("3PL đường bộ và last-mile thương mại điện tử");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Center, {
		title: "Đăng ký doanh nghiệp",
		text: "Tạo hồ sơ thí điểm trên trình duyệt này. Không mở tài khoản máy chủ.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: (event) => {
				event.preventDefault();
				if (!name.trim() || !email.trim()) return;
				setProfile({
					name: name.trim(),
					email: email.trim(),
					segment,
					updated: "hồ sơ vừa tạo"
				});
				sessionStorage.setItem("verdex-session", "enterprise");
				navigate({ to: "/goi-dich-vu" });
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tên doanh nghiệp",
					value: name,
					onChange: setName,
					type: "text"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					value: email,
					onChange: setEmail,
					type: "email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm text-slate-600",
					children: ["Nhóm hoạt động", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: segment,
						onChange: (event) => setSegment(event.target.value),
						className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-slate-900",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "3PL đường bộ và last-mile thương mại điện tử" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Kho bãi và depot container" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Chủ hàng thương mại điện tử" })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "min-h-11 w-full rounded-xl bg-emerald-700 text-sm font-semibold text-emerald-50",
					children: "Tạo hồ sơ"
				})
			]
		})
	});
}
function PlanPage() {
	const plan = useVerdex((state) => state.plan);
	const setPlan = useVerdex((state) => state.setPlan);
	const profile = useVerdex((state) => state.profile);
	const setProfile = useVerdex((state) => state.setProfile);
	const verdict = useVerdict();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-emerald-700 uppercase",
					children: "Freemium"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-semibold tracking-tight sm:text-3xl",
					children: "Hồ sơ và gói dịch vụ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 max-w-3xl text-sm leading-6 text-slate-600",
					children: [
						"Đổi gói không đổi Green Score, Data Confidence, Coverage, nhận thức hay Gap. Điểm hiện tại là ",
						verdict.greenScore ?? "—",
						". Chọn gói khác và xem điểm trên thanh trạng thái không đổi."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 rounded-2xl border border-slate-200 bg-white p-5 sm:grid-cols-2",
				onSubmit: (event) => {
					event.preventDefault();
					const data = new FormData(event.currentTarget);
					setProfile({
						name: String(data.get("name") || profile.name),
						email: String(data.get("email") || profile.email),
						segment: String(data.get("segment") || profile.segment)
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-slate-600",
						children: ["Tên", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "name",
							defaultValue: profile.name,
							className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 px-3"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-slate-600",
						children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "email",
							defaultValue: profile.email,
							className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 px-3"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-slate-600 sm:col-span-2",
						children: ["Nhóm hoạt động", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "segment",
							defaultValue: profile.segment,
							className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 px-3"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 rounded-xl border border-slate-200 px-4 text-sm font-semibold sm:col-span-2",
						children: "Lưu hồ sơ"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: PLANS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("rounded-2xl border bg-white p-5", plan === item.id ? "border-emerald-600" : "border-slate-200"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-slate-500",
							children: item.price
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-1 text-sm text-slate-700",
							children: item.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: point }, point))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setPlan(item.id),
							className: "mt-4 min-h-11 rounded-xl bg-slate-900 px-4 text-sm font-semibold text-slate-50",
							children: plan === item.id ? "Đang dùng" : "Chọn gói"
						})
					]
				}, item.id))
			})
		]
	}) });
}
function Field({ label, value, onChange, type }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm text-slate-600",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			value,
			onChange: (event) => onChange(event.target.value),
			className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 px-3 text-slate-900"
		})]
	});
}
//#endregion
export { PlanPage as n, RegisterPage as r, LoginPage as t };
