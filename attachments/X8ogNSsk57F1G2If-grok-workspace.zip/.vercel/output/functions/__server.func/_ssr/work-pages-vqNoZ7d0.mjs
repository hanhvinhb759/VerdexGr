import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, c as useVerdict, o as pillarItems, r as PILLARS, s as useVerdex, t as CRITERIA } from "./utils-B1f16EgT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/work-pages-vqNoZ7d0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	{
		id: "implemented",
		label: "Implemented"
	},
	{
		id: "not_implemented",
		label: "Not Implemented"
	},
	{
		id: "na",
		label: "Not Applicable"
	},
	{
		id: "insufficient",
		label: "Insufficient Data"
	}
];
var LEVELS = [
	{
		id: "self",
		label: "Self-reported · 30"
	},
	{
		id: "evidence",
		label: "Evidence-supported · 60"
	},
	{
		id: "cross",
		label: "Cross-checked · 80"
	},
	{
		id: "external",
		label: "Externally verified · 100"
	}
];
function ItemEditor({ item }) {
	const state = useVerdex((store) => store.items[item.id]);
	const setItem = useVerdex((store) => store.setItem);
	if (!state) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-slate-200 bg-white p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold",
				children: item.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-slate-500",
				children: item.pillar
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-xs text-slate-500",
				children: ["Điểm thực hành", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					max: 100,
					value: state.score,
					onChange: (event) => setItem(item.id, { score: clamp(Number(event.target.value)) }),
					className: "mt-1 block w-24 min-h-11 rounded-xl border border-slate-200 px-3 text-sm font-semibold text-slate-900"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-slate-500",
					children: ["Trạng thái", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: state.status,
						onChange: (event) => setItem(item.id, { status: event.target.value }),
						className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900",
						children: STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: status.id,
							children: status.label
						}, status.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-slate-500",
					children: ["Mức xác thực", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: state.verify,
						onChange: (event) => setItem(item.id, { verify: event.target.value }),
						className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900",
						children: LEVELS.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: level.id,
							children: level.label
						}, level.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-slate-500",
					children: ["Số ngày từ lần cập nhật", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						value: state.days,
						onChange: (event) => setItem(item.id, { days: Math.max(0, Number(event.target.value) || 0) }),
						className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 px-3 text-sm text-slate-900"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-end gap-2 text-sm text-slate-700",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: state.evidence,
							onChange: (event) => setItem(item.id, { evidence: event.target.checked })
						}), "Có minh chứng phù hợp"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: state.clash,
							onChange: (event) => setItem(item.id, { clash: event.target.checked })
						}), "Lệch giữa các nguồn"]
					})]
				})
			]
		})]
	});
}
function clamp(value) {
	if (Number.isNaN(value)) return 0;
	return Math.min(100, Math.max(0, value));
}
function Head({ kicker, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-wide text-emerald-700 uppercase",
			children: kicker
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 text-2xl font-semibold tracking-tight sm:text-3xl",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-3xl text-sm leading-6 text-slate-600",
			children: text
		})
	] });
}
function DataPage() {
	const [pillar, setPillar] = (0, import_react.useState)("all");
	const list = CRITERIA.filter((item) => pillar === "all" || item.pillar === pillar);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Giai đoạn 2",
				title: "Nhập liệu vận hành và minh chứng",
				text: "Dữ liệu tự khai không được xem là đã xác thực. Đổi trạng thái, mức xác thực hoặc minh chứng sẽ tính lại Green Score, Coverage và Data Confidence trên mọi trang."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					active: pillar === "all",
					onClick: () => setPillar("all"),
					label: "Tất cả"
				}), PILLARS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					active: pillar === item.id,
					onClick: () => setPillar(item.id),
					label: item.vi
				}, item.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-500",
				children: "Hệ thống không đọc chứng từ thay kiểm toán. Nó chỉ ghi mức doanh nghiệp khai và đối chiếu cờ lệch nguồn."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemEditor, { item }, item.id))
			})
		]
	});
}
function PillarsPage() {
	const verdict = useVerdict();
	const [current, setCurrent] = (0, import_react.useState)("P");
	const currentPillar = verdict.pillars.find((item) => item.id === current);
	const currentRows = pillarItems(verdict, current);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Giai đoạn 2",
				title: "Ba trụ vận hành",
				text: "Điểm trụ là trung bình các tiêu chí Implemented. Not Implemented và Insufficient Data làm cả trụ không đủ điều kiện đưa vào OGS, chứ không bị tính bằng 0."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"P",
					"T",
					"R"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					active: current === key,
					onClick: () => setCurrent(key),
					label: PILLARS.find((item) => item.id === key)?.vi ?? key
				}, key))
			}),
			currentPillar ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-slate-200 bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-slate-500",
						children: currentPillar.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl font-semibold tabular-nums",
						children: currentPillar.score ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-slate-600",
						children: [currentPillar.status, currentPillar.eligible ? " · đủ điều kiện vào OGS" : " · chưa vào OGS"]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: currentRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemEditor, { item: row }, row.id))
			})
		]
	});
}
function TransparencyPage() {
	const verdict = useVerdict();
	const pillar = verdict.pillars.find((item) => item.id === "TGS");
	const rows = pillarItems(verdict, "TGS");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Giai đoạn 2",
				title: "Minh bạch và truyền thông",
				text: "Trụ này không ngang hàng với đóng gói, vận chuyển và logistics ngược. Nó chỉ được cộng tối đa 15% và không được kéo Green Score vượt Operational Green Score quá 10 điểm."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-slate-200 bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-slate-500",
						children: "Transparency and Green Communication Score"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl font-semibold tabular-nums",
						children: pillar?.score ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm leading-6 text-slate-600",
						children: [
							"Điểm trước trần ",
							verdict.rawScore ?? "—",
							". Trần ",
							verdict.cap ?? "—",
							". Green Score công bố ",
							verdict.greenScore ?? "—",
							"."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemEditor, { item: row }, row.id))
			})
		]
	});
}
function MatrixPage() {
	const verdict = useVerdict();
	const weights = [
		[
			"Evidence Completeness",
			verdict.parts.evidence,
			"20%"
		],
		[
			"Source Consistency",
			verdict.parts.consistency,
			"20%"
		],
		[
			"Data Recency",
			verdict.parts.recency,
			"15%"
		],
		[
			"Validation and Verification",
			verdict.parts.verification,
			"45%"
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Giai đoạn 2",
				title: "Ma trận điểm, phạm vi và độ tin cậy",
				text: "Ba con số phải được đọc cùng nhau. Green Score không phải chứng nhận xanh. Trọng số dưới đây là tham số prototype."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "overflow-x-auto rounded-2xl border border-slate-200 bg-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[36rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-slate-200 text-slate-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Trụ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Trạng thái"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Vào OGS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Điểm"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: verdict.pillars.map((pillar) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-slate-100",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium",
								children: pillar.vi
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: pillar.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: pillar.inOgs ? pillar.eligible ? "Có" : "Không, chưa đủ điều kiện" : "Không, trụ bổ trợ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: pillar.score ?? "—"
							})
						]
					}, pillar.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-slate-200 bg-white p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Green Score"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "OGS",
								value: verdict.ogsLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Trước trần",
								value: verdict.rawScore ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Trần OGS + 10",
								value: verdict.cap ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Công bố",
								value: verdict.greenScore ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Coverage",
								value: verdict.coverageLabel
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-slate-200 bg-white p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-lg font-semibold",
							children: ["Data Confidence ", verdict.confidence]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-emerald-800",
							children: verdict.confidenceBand
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3",
							children: weights.map(([label, score, weight]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold tabular-nums",
									children: [
										score,
										" · ",
										weight
									]
								})]
							}, label))
						})
					]
				})]
			})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-4 border-b border-slate-100 pb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-slate-600",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-semibold tabular-nums",
			children: value
		})]
	});
}
function Filter({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("min-h-11 rounded-full px-4 text-sm font-medium", active ? "bg-emerald-700 text-emerald-50" : "border border-slate-200 bg-white text-slate-700"),
		children: label
	});
}
//#endregion
export { TransparencyPage as i, MatrixPage as n, PillarsPage as r, DataPage as t };
