import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as EnterpriseShell } from "./enterprise-shell-DEfrS-6K.mjs";
import { r as ReassessPage } from "./intel-pages-DND5EsYe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/danh-gia-lai-9KC7njEC.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function DanhGiaLai() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReassessPage, {}) });
};
//#endregion
export { SplitComponent as component };
