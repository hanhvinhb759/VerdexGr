import { r as RegisterPage } from "./account-pages-BS_GSM2g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dang-ky-CMRTwC7d.js
var SplitComponent = RegisterPage;
//#endregion
export { SplitComponent as component };
