import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, c as useVerdict, s as useVerdex } from "./utils-B1f16EgT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/intel-pages-DND5EsYe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Head({ kicker, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-wide text-indigo-700 uppercase",
			children: kicker
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 text-2xl font-semibold tracking-tight sm:text-3xl",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-3xl text-sm leading-6 text-slate-600",
			children: text
		})
	] });
}
function DiagnosisPage() {
	const verdict = useVerdict();
	const low = verdict.rows.filter((row) => row.status === "implemented" && row.score < 70).sort((a, b) => a.score - b.score);
	const flags = verdict.rows.filter((row) => row.status !== "na" && (!row.evidence || row.clash || row.verify === "self"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Vai trò chẩn đoán",
				title: "Chẩn đoán theo luật",
				text: "Bốn vai trò là Assessment, Diagnosis, Recommendation và Feedback Intelligence. Phần này không gọi mô hình ngôn ngữ và không kết luận greenwashing."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					["Assessment", `OGS ${verdict.ogsLabel}. Coverage ${verdict.coverageLabel}.`],
					["Diagnosis", verdict.weakest ? `${verdict.weakest.vi} là trụ vận hành thấp nhất.` : "Chưa đủ trụ để chỉ nguyên nhân."],
					["Recommendation", "Khuyến nghị lấy từ thư viện gắn với tiêu chí dưới 70 điểm."],
					["Feedback Intelligence", verdict.gapText]
				].map(([title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-indigo-200 bg-indigo-50 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold text-indigo-900",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-indigo-950",
						children: text
					})]
				}, title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-slate-200 bg-white p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Tiêu chí kéo điểm xuống"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: [low.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Không có tiêu chí Implemented dưới 70." }) : null, low.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3 border-b border-slate-100 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold tabular-nums",
							children: row.score
						})]
					}, row.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-slate-200 bg-white p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Cờ dữ liệu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm text-slate-700",
					children: [flags.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Không có cờ thiếu minh chứng, lệch nguồn hoặc tự khai đơn thuần." }) : null, flags.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						row.name,
						": ",
						!row.evidence ? "thiếu minh chứng. " : "",
						row.clash ? "lệch nguồn. " : "",
						row.verify === "self" ? "chỉ self-reported." : ""
					] }, row.id))]
				})]
			})
		]
	});
}
function RecommendPage() {
	const verdict = useVerdict();
	const done = useVerdex((state) => state.done);
	const toggleDone = useVerdex((state) => state.toggleDone);
	const queue = verdict.rows.filter((row) => row.status === "implemented" && (row.score < 70 || !row.evidence || row.clash));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
			kicker: "Vai trò khuyến nghị",
			title: "Kế hoạch hành động",
			text: "Mỗi khuyến nghị gắn với một tiêu chí. Đánh dấu đã làm chỉ để theo dõi. Điểm chỉ đổi khi dữ liệu ở trang nhập liệu đổi."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [queue.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-600",
				children: "Không còn tiêu chí dưới ngưỡng 70 hoặc thiếu minh chứng."
			}) : null, queue.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-slate-200 bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold",
							children: row.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold tabular-nums",
							children: row.score
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-slate-600",
						children: row.action
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => toggleDone(row.id),
						className: cn("mt-3 min-h-11 rounded-xl px-4 text-sm font-semibold", done[row.id] ? "bg-emerald-50 text-emerald-800" : "bg-indigo-600 text-indigo-50"),
						children: done[row.id] ? "Đã ghi vào checklist" : "Ghi vào checklist"
					})
				]
			}, row.id))]
		})]
	});
}
function GapPage() {
	const verdict = useVerdict();
	const themes = useVerdex((state) => state.perception.themes);
	const max = Math.max(...themes.map((theme) => theme.count), 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Feedback Intelligence",
				title: "Khoảng cách nhận thức",
				text: "Phản hồi khách hàng không được tự trừ Green Score. Gap chính thức cần từ 50 đánh giá, coverage không ở mức không đủ phạm vi, và Data Confidence từ 50."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						label: "Green Score",
						value: verdict.greenScore ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						label: "Customer perception",
						value: verdict.perception
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						label: "Gap",
						value: verdict.gapOfficial ? String(verdict.gap) : "Chưa đủ"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-amber-200 bg-white p-4 text-sm leading-6 text-slate-700",
				children: verdict.gapText
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-slate-200 bg-white p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Chủ đề được nhắc"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: themes.map((theme) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: theme.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: theme.count
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1.5 rounded-full bg-slate-100",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-amber-500",
							style: { width: `${theme.count / max * 100}%` }
						})
					})] }, theme.id))
				})]
			})
		]
	});
}
function ReassessPage() {
	const verdict = useVerdict();
	const history = useVerdex((state) => state.history);
	const commit = useVerdex((state) => state.commitPeriod);
	const reset = useVerdex((state) => state.reset);
	const [label, setLabel] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				kicker: "Vòng khép",
				title: "Đánh giá lại và tiến độ",
				text: "Chốt kỳ lưu Green Score hiện tại vào diễn biến. Đặt lại hồ sơ mẫu đưa dữ liệu về trạng thái ban đầu của phiên trình diễn."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-5 sm:flex-row sm:items-end",
				onSubmit: (event) => {
					event.preventDefault();
					if (verdict.greenScore === null) {
						setNote("Chưa đủ phạm vi để chốt kỳ.");
						return;
					}
					commit(label);
					setLabel("");
					setNote(`Đã lưu ${verdict.greenScore} điểm.`);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex-1 text-sm text-slate-600",
						children: ["Tên kỳ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: label,
							onChange: (event) => setLabel(event.target.value),
							placeholder: "Ví dụ T10",
							className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 px-3 text-slate-900"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 rounded-xl bg-emerald-700 px-4 text-sm font-semibold text-emerald-50",
						children: "Chốt kỳ này"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							reset();
							setNote("Đã trở lại hồ sơ mẫu.");
						},
						className: "min-h-11 rounded-xl border border-slate-200 px-4 text-sm font-semibold text-slate-800",
						children: "Đặt lại hồ sơ mẫu"
					})
				]
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-slate-600",
				children: note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: [history.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-slate-200 bg-white px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-500",
						children: point.period
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xl font-semibold tabular-nums",
						children: point.score
					})]
				}, `${point.period}-${point.score}`)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-emerald-800",
						children: "Hiện tại"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xl font-semibold tabular-nums",
						children: verdict.greenScore ?? "—"
					})]
				})]
			})
		]
	});
}
function Card({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-slate-200 bg-white p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-slate-500",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-2xl font-semibold tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { RecommendPage as i, GapPage as n, ReassessPage as r, DiagnosisPage as t };
