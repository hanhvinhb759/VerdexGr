import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as EnterpriseShell } from "./enterprise-shell-DEfrS-6K.mjs";
import { i as RecommendPage } from "./intel-pages-DND5EsYe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/khuyen-nghi-CEjUqXtA.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function KhuyenNghi() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecommendPage, {}) });
};
//#endregion
export { SplitComponent as component };
