import { n as PlanPage } from "./account-pages-BS_GSM2g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/goi-dich-vu-DxU7rzoY.js
var SplitComponent = PlanPage;
//#endregion
export { SplitComponent as component };
