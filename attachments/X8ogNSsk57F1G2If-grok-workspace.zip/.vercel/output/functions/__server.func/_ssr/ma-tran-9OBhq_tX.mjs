import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as EnterpriseShell } from "./enterprise-shell-DEfrS-6K.mjs";
import { n as MatrixPage } from "./work-pages-vqNoZ7d0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ma-tran-9OBhq_tX.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function MaTran() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatrixPage, {}) });
};
//#endregion
export { SplitComponent as component };
