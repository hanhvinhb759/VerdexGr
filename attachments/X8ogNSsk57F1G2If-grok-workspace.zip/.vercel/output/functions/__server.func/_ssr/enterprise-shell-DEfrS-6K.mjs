import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, b as Link, p as useRouterState, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, c as useVerdict, i as PLANS, s as useVerdex } from "./utils-B1f16EgT.mjs";
import { a as Stethoscope, c as Recycle, d as Megaphone, f as Lightbulb, h as CreditCard, i as TableProperties, l as Package, m as LayoutDashboard, n as Truck, o as Scale, p as Leaf, s as RefreshCw, t as X, u as Menu } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enterprise-shell-DEfrS-6K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var groups = [
	{
		title: "Vận hành",
		items: [
			{
				label: "Tổng quan",
				to: "/tong-quan",
				icon: LayoutDashboard
			},
			{
				label: "Nhập liệu và minh chứng",
				to: "/nhap-lieu",
				icon: Package
			},
			{
				label: "Ba trụ vận hành",
				to: "/tru-van-hanh",
				icon: Truck
			},
			{
				label: "Minh bạch truyền thông",
				to: "/minh-bach",
				icon: Megaphone
			},
			{
				label: "Ma trận điểm số",
				to: "/ma-tran",
				icon: TableProperties
			}
		]
	},
	{
		title: "Vòng cải thiện",
		items: [
			{
				label: "Chẩn đoán",
				to: "/chan-doan",
				icon: Stethoscope
			},
			{
				label: "Khuyến nghị",
				to: "/khuyen-nghi",
				icon: Lightbulb
			},
			{
				label: "Khoảng cách nhận thức",
				to: "/khoang-cach",
				icon: Scale
			},
			{
				label: "Đánh giá lại",
				to: "/danh-gia-lai",
				icon: RefreshCw
			}
		]
	},
	{
		title: "Thiết lập",
		items: [{
			label: "Hồ sơ và gói dịch vụ",
			to: "/goi-dich-vu",
			icon: CreditCard
		}]
	}
];
function NavList({ pathname, onNavigate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "flex flex-1 flex-col gap-6 overflow-y-auto px-3 py-4",
		"aria-label": "Phân hệ doanh nghiệp",
		children: [groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-3 pb-2 text-xs font-semibold tracking-wide text-slate-500 uppercase",
			children: group.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1",
			children: group.items.map((item) => {
				const Icon = item.icon;
				const active = pathname === item.to;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					onClick: onNavigate,
					className: cn("flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm", active ? "bg-emerald-50 font-semibold text-emerald-800" : "text-slate-600 hover:bg-slate-50"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-4 shrink-0",
						"aria-hidden": "true"
					}), item.label]
				}) }, item.to);
			})
		})] }, group.title)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			onClick: onNavigate,
			className: "px-3 text-sm font-medium text-slate-500",
			children: "Về cổng công khai"
		})]
	});
}
function Brand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/tong-quan",
		className: "flex items-center gap-3 px-5 pt-5 pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-10 items-center justify-center rounded-xl bg-emerald-700 text-emerald-50",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
				className: "size-5",
				"aria-hidden": "true"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-base font-semibold tracking-tight text-slate-900",
			children: "Verdex"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-slate-500",
			children: "Green Score logistics"
		})] })]
	});
}
function IntegrityPills() {
	const verdict = useVerdict();
	const pills = [
		{
			label: "Green Score",
			value: verdict.greenScore === null ? "—" : String(verdict.greenScore)
		},
		{
			label: "Coverage",
			value: verdict.coverageDetail.split(" ")[0] ?? "—"
		},
		{
			label: "Confidence",
			value: String(verdict.confidence)
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-wrap gap-2",
		children: pills.map((pill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-baseline gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-slate-500",
				children: pill.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-semibold text-slate-900 tabular-nums",
				children: pill.value
			})]
		}, pill.label))
	});
}
function EnterpriseShell({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const profile = useVerdex((state) => state.profile);
	const plan = useVerdex((state) => state.plan);
	const planName = PLANS.find((item) => item.id === plan)?.name ?? plan;
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onKey(event) {
			if (event.key === "Escape") setOpen(false);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-slate-50 text-slate-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-72 flex-col border-r border-slate-200 bg-white lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavList, {
						pathname,
						onNavigate: () => setOpen(false)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-slate-200 px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: profile.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-slate-500",
							children: [
								profile.code,
								" · ",
								planName
							]
						})]
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-slate-900/40",
					"aria-label": "Đóng menu",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "relative flex h-full w-72 flex-col bg-white shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between pr-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-5 flex size-11 items-center justify-center rounded-xl text-slate-700",
							onClick: () => setOpen(false),
							"aria-label": "Đóng menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavList, {
						pathname,
						onNavigate: () => setOpen(false)
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:pl-72",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-20 border-b border-slate-200 bg-slate-50/95 backdrop-blur",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex size-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-800 lg:hidden",
								"aria-expanded": open,
								"aria-label": "Mở menu",
								onClick: () => setOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-semibold",
									children: profile.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-slate-500",
									children: profile.segment
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityPills, {})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "px-4 py-6 sm:px-6 lg:px-8 lg:py-8",
					children
				})]
			})
		]
	});
}
function iconForPillar(id) {
	if (id === "P") return Package;
	if (id === "T") return Truck;
	if (id === "R") return Recycle;
	return Megaphone;
}
//#endregion
export { iconForPillar as n, EnterpriseShell as t };
