import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as EnterpriseShell } from "./enterprise-shell-DEfrS-6K.mjs";
import { t as DataPage } from "./work-pages-vqNoZ7d0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nhap-lieu-CBttZCEA.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function NhapLieu() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPage, {}) });
};
//#endregion
export { SplitComponent as component };
