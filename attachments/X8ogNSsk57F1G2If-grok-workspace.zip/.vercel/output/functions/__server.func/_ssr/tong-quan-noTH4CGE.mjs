import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, c as useVerdict, i as PLANS, s as useVerdex } from "./utils-B1f16EgT.mjs";
import { n as iconForPillar, t as EnterpriseShell } from "./enterprise-shell-DEfrS-6K.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tong-quan-noTH4CGE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ScoreRing({ value }) {
	const size = 148;
	const stroke = 12;
	const radius = 68;
	const circumference = 2 * Math.PI * radius;
	const offset = circumference - value / 100 * circumference;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: `0 0 ${size} ${size}`,
		role: "img",
		"aria-label": `Green Score ${value} trên 100`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: size / 2,
			cy: size / 2,
			r: radius,
			fill: "none",
			className: "stroke-slate-200",
			strokeWidth: stroke
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: size / 2,
			cy: size / 2,
			r: radius,
			fill: "none",
			className: "stroke-emerald-600",
			strokeWidth: stroke,
			strokeLinecap: "round",
			strokeDasharray: circumference,
			strokeDashoffset: offset,
			transform: `rotate(-90 ${size / 2} ${size / 2})`
		})]
	});
}
function toneClass(tone) {
	if (tone === "weak") return "bg-rose-500";
	if (tone === "watch") return "bg-amber-500";
	if (tone === "off") return "bg-slate-300";
	return "bg-emerald-600";
}
function OverviewDashboard() {
	const [chartReady, setChartReady] = (0, import_react.useState)(false);
	const [stepId, setStepId] = (0, import_react.useState)("dx");
	const verdict = useVerdict();
	const profile = useVerdex((state) => state.profile);
	const plan = useVerdex((state) => state.plan);
	const planName = PLANS.find((item) => item.id === plan)?.name ?? plan;
	const activeStep = verdict.loop.find((step) => step.id === stepId) ?? verdict.loop[5];
	(0, import_react.useEffect)(() => {
		setChartReady(true);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-emerald-700 uppercase",
						children: "Phân hệ vận hành"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-semibold tracking-tight sm:text-3xl",
						children: "Bảng tổng quan doanh nghiệp"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-2xl text-sm leading-6 text-slate-600",
						children: [
							profile.name,
							" · ",
							profile.code,
							". Hồ sơ cập nhật ",
							profile.updated,
							". Điểm số không thay đổi theo gói ",
							planName,
							"."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#cong-thuc",
					className: "inline-flex min-h-11 items-center justify-center rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-800",
					children: "Xem cách tính điểm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-slate-200 bg-white p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-slate-500",
						children: "Green Score"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative grid place-items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, { value: verdict.greenScore ?? 0 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "absolute text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-4xl font-semibold tracking-tight tabular-nums",
									children: verdict.greenScore ?? "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-slate-500",
									children: "/ 100"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-6 text-slate-600",
							children: "Không phải chứng nhận xanh. Đọc cùng phạm vi đánh giá và độ tin cậy dữ liệu."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs font-medium text-emerald-800",
							children: ["Operational Green Score ", verdict.ogsLabel]
						})] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: "rounded-2xl border border-slate-200 bg-white p-5 lg:col-span-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-slate-500",
								children: "Assessment Coverage"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xl font-semibold tracking-tight",
								children: verdict.coverageLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-6 text-slate-600",
								children: [verdict.coverageDetail, ". Tiêu chí Not Implemented hoặc Insufficient Data không bị tính như điểm không."]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-slate-500",
								children: "Data Confidence"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xl font-semibold tracking-tight tabular-nums",
								children: [verdict.confidence, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base font-medium text-slate-500",
									children: " / 100"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 inline-flex rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-800",
								children: verdict.confidenceBand
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-6 text-slate-600",
								children: [
									"Minh chứng đầy đủ ",
									verdict.parts.evidence,
									", nhất quán ",
									verdict.parts.consistency,
									", cập nhật ",
									verdict.parts.recency,
									", xác thực ",
									verdict.parts.verification,
									"."
								]
							})
						] })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-label": "Bốn trụ",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight",
					children: "Ba trụ vận hành và trụ minh bạch"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
					children: verdict.pillars.map((pillar) => {
						const Icon = iconForPillar(pillar.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl border border-slate-200 bg-white p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4",
											"aria-hidden": "true"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-2xl font-semibold tabular-nums",
										children: pillar.score
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 text-sm font-semibold",
									children: pillar.vi
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-slate-500",
									children: [
										pillar.id,
										" · ",
										pillar.name
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 h-1.5 overflow-hidden rounded-full bg-slate-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: cn("h-full rounded-full", toneClass(pillar.tone)),
										style: { width: `${pillar.score ?? 0}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-6 text-slate-600",
									children: pillar.note
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-xs font-medium text-slate-500",
									children: [pillar.status, pillar.inOgs ? " · tính vào OGS" : " · không tính vào OGS"]
								})
							]
						}, pillar.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-slate-200 bg-white p-5 lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold tracking-tight",
							children: "Diễn biến Green Score"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-slate-500",
							children: "Sáu kỳ gần nhất, sau làm tròn số nguyên."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-56",
							children: chartReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
									data: verdict.trend,
									margin: {
										top: 8,
										right: 8,
										left: 0,
										bottom: 0
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-slate-200)",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "period",
											tick: {
												fill: "var(--color-slate-500)",
												fontSize: 12
											},
											axisLine: false,
											tickLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											domain: [0, 100],
											tick: {
												fill: "var(--color-slate-500)",
												fontSize: 12
											},
											axisLine: false,
											tickLine: false,
											width: 32
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
											background: "var(--color-white)",
											border: "1px solid var(--color-slate-200)",
											borderRadius: "0.75rem",
											fontSize: "0.75rem"
										} }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "score",
											name: "Green Score",
											stroke: "var(--color-emerald-700)",
											fill: "var(--color-emerald-100)",
											strokeWidth: 2
										})
									]
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-xl bg-slate-100" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					id: "cong-thuc",
					className: "scroll-mt-24 rounded-2xl border border-slate-200 bg-white p-5 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold tracking-tight",
							children: "Cách cộng điểm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 space-y-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-4 border-b border-slate-100 pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-slate-600",
										children: "OGS, trung bình nhân P, T, R"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-semibold tabular-nums",
										children: verdict.ogsLabel
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-4 border-b border-slate-100 pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-slate-600",
										children: "Trước trần: 85% OGS + 15% TGS"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-semibold tabular-nums",
										children: verdict.rawScore ?? "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-4 border-b border-slate-100 pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-slate-600",
										children: "Trần OGS + 10"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-semibold tabular-nums",
										children: verdict.cap ?? "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-medium text-slate-900",
										children: "Green Score công bố"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-lg font-semibold text-emerald-800 tabular-nums",
										children: verdict.greenScore ?? "—"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-5 text-slate-500",
							children: "Trọng số và trần là tham số prototype. Trung bình nhân buộc trụ yếu phải được nâng, không để một trụ cao che trụ thấp."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-slate-200 bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold tracking-tight",
							children: "Vòng cải thiện khép kín"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-slate-500",
							children: "Chọn một chặng để xem trạng thái hiện tại của hồ sơ."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-indigo-700",
							children: "Đang ở chẩn đoán"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4",
						children: verdict.loop.map((step, index) => {
							const selected = step.id === stepId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setStepId(step.id),
								className: cn("flex min-h-16 w-full items-center gap-3 rounded-xl border px-3 py-2 text-left", selected ? "border-indigo-300 bg-indigo-50" : "border-slate-200 bg-white"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("flex size-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold", step.state === "now" && "bg-indigo-600 text-indigo-50", step.state === "done" && "bg-emerald-100 text-emerald-800", step.state === "wait" && "bg-slate-100 text-slate-500"),
									children: index + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-semibold",
									children: step.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-slate-500",
									children: step.state === "done" ? "Đã xong" : step.state === "now" ? "Đang xử lý" : "Chưa tới"
								})] })]
							}) }, step.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-xl bg-indigo-50 px-4 py-3 text-sm leading-6 text-indigo-950",
						children: activeStep.detail
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-rose-200 bg-white p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-rose-700 uppercase",
								children: "Điểm nghẽn vận hành"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-base font-semibold",
								children: verdict.weakest ? `${verdict.weakest.vi} đang thấp nhất` : "Chưa đủ trụ để chỉ điểm nghẽn"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-6 text-slate-600",
								children: verdict.weakest ? `${verdict.weakest.vi} ở ${verdict.weakest.score}. Trung bình nhân OGS là ${verdict.ogsLabel}. Một trụ cao không che được trụ thấp.` : "Cần ít nhất hai trụ vận hành đủ điều kiện để công bố OGS."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-amber-200 bg-white p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-amber-700 uppercase",
								children: "Green Perception Gap"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-base font-semibold",
								children: verdict.gapOfficial ? `${verdict.gapBand} · ${verdict.gap}` : "Chưa công bố chính thức"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-6 text-slate-600",
								children: [
									"Green Score ",
									verdict.greenScore ?? "—",
									", nhận thức ",
									verdict.perception,
									" trên ",
									verdict.reviewCount,
									" đánh giá. ",
									verdict.gapText
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-slate-200 bg-white p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-slate-500 uppercase",
								children: "Độ tin cậy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-base font-semibold",
								children: "Xác thực chiếm 45%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-6 text-slate-600",
								children: [
									"Số mục externally verified: ",
									verdict.externalCount,
									". Data Confidence ",
									verdict.confidenceExact,
									", làm tròn ",
									verdict.confidence,
									", nhãn ",
									verdict.confidenceBand,
									". Thiếu minh chứng: ",
									verdict.evidenceMissing,
									" tiêu chí."
								]
							})
						]
					})
				]
			})
		]
	});
}
var SplitComponent = function TongQuan() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewDashboard, {}) });
};
//#endregion
export { SplitComponent as component };
