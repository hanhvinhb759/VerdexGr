import { t as HomePage } from "./public-pages-DcZBMsfr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D5Qlc9Tn.js
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
