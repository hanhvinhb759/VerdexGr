import { i as __toESM } from "../_runtime.mjs";
import { S as useParams, X as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, c as useVerdict, n as PEERS, s as useVerdex } from "./utils-B1f16EgT.mjs";
import { p as Leaf } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/public-pages-DcZBMsfr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PublicFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-slate-50 text-slate-900",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-slate-200 bg-white",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center rounded-xl bg-emerald-700 text-emerald-50",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
							className: "size-4",
							"aria-hidden": "true"
						})
					}), "Verdex"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-wrap gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dang-nhap",
						className: "inline-flex min-h-11 items-center px-3 text-slate-700",
						children: "Đăng nhập"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dang-ky",
						className: "inline-flex min-h-11 items-center rounded-xl bg-emerald-700 px-4 font-semibold text-emerald-50",
						children: "Đăng ký doanh nghiệp"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto max-w-6xl px-4 py-8",
			children
		})]
	});
}
function HomePage() {
	const verdict = useVerdict();
	const profile = useVerdex((state) => state.profile);
	const [query, setQuery] = (0, import_react.useState)("");
	const [picked, setPicked] = (0, import_react.useState)([]);
	const cards = (0, import_react.useMemo)(() => {
		return [{
			code: profile.code,
			name: profile.name,
			segment: profile.segment,
			greenScore: verdict.greenScore,
			confidence: verdict.confidence,
			band: verdict.confidenceBand,
			coverage: verdict.coverageLabel,
			comparable: true,
			note: "Hồ sơ thí điểm. Điểm đổi theo dữ liệu doanh nghiệp nhập.",
			live: true
		}, ...PEERS.map((peer) => ({
			...peer,
			live: false,
			greenScore: peer.greenScore
		}))];
	}, [profile, verdict]);
	const visible = cards.filter((card) => `${card.name} ${card.code} ${card.segment}`.toLowerCase().includes(query.trim().toLowerCase()));
	const selected = cards.filter((card) => picked.includes(card.code));
	const blocked = selected.length === 2 && selected.some((card) => !card.comparable || selected[0]?.segment !== selected[1]?.segment);
	function toggle(code) {
		setPicked((current) => {
			if (current.includes(code)) return current.filter((item) => item !== code);
			if (current.length >= 2) return [current[1], code];
			return [...current, code];
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-wide text-emerald-700 uppercase",
			children: "Cổng công khai"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 max-w-3xl text-3xl font-semibold tracking-tight sm:text-4xl",
			children: "Đọc logistics xanh cùng phạm vi và độ tin cậy"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-6 text-slate-600",
			children: "Green Score không đứng một mình. Mỗi hồ sơ hiện Assessment Coverage và Data Confidence. Quảng cáo không đổi thứ hạng."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-6 block text-sm text-slate-600",
			children: ["Tìm doanh nghiệp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				className: "mt-1 block min-h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-slate-900",
				placeholder: "Tên hoặc mã"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 md:grid-cols-3",
			children: visible.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex flex-col rounded-2xl border border-slate-200 bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-500",
						children: card.code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-lg font-semibold",
						children: card.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-6 text-slate-600",
						children: card.segment
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-3xl font-semibold tabular-nums",
						children: card.greenScore ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-slate-600",
						children: [
							card.band,
							" · ",
							card.confidence
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-slate-500",
						children: card.coverage
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/doanh-nghiep/$code",
							params: { code: card.code },
							className: "inline-flex min-h-11 items-center rounded-xl bg-slate-900 px-3 text-sm font-semibold text-slate-50",
							children: "Xem hồ sơ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggle(card.code),
							className: "min-h-11 rounded-xl border border-slate-200 px-3 text-sm",
							children: picked.includes(card.code) ? "Bỏ so sánh" : "So sánh"
						})]
					})
				]
			}, card.code))
		}),
		selected.length === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-2xl border border-slate-200 bg-white p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "So sánh hai hồ sơ"
			}), blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-6 text-slate-600",
				children: "Hai hồ sơ khác nhóm hoạt động hoặc chưa cùng điều kiện so sánh. Hệ thống không xếp bên cạnh hai Green Score này."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: selected.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-slate-50 p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: card.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 tabular-nums",
							children: ["Green Score ", card.greenScore ?? "—"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Data Confidence ", card.confidence] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: card.coverage })
					]
				}, card.code))
			})]
		}) : null
	] });
}
function ProfilePage() {
	const { code } = useParams({ strict: false });
	const verdict = useVerdict();
	const profile = useVerdex((state) => state.profile);
	const peer = PEERS.find((item) => item.code === code);
	const live = code === profile.code;
	if (!live && !peer) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-2xl font-semibold",
		children: "Không thấy hồ sơ"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-emerald-800",
		children: "Về danh bạ"
	})] });
	const name = live ? profile.name : peer?.name;
	const score = live ? verdict.greenScore : peer?.greenScore;
	const confidence = live ? verdict.confidence : peer?.confidence;
	const band = live ? verdict.confidenceBand : peer?.band;
	const coverage = live ? verdict.coverageLabel : peer?.coverage;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-slate-500",
			children: code
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 text-3xl font-semibold tracking-tight",
			children: name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm leading-6 text-slate-600",
			children: live ? profile.segment : peer?.note
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Green Score",
					value: score ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Assessment Coverage",
					value: coverage ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Data Confidence",
					value: `${confidence ?? "—"} · ${band ?? ""}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-slate-600",
			children: "Kết quả phản ánh hồ sơ đã đánh giá, không phải chứng nhận doanh nghiệp xanh. Toàn văn chứng từ không được mở trên trang này."
		}),
		live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: verdict.pillars.map((pillar) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-slate-200 bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: pillar.vi
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-2xl font-semibold tabular-nums",
						children: pillar.score ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-500",
						children: pillar.status
					})
				]
			}, pillar.id))
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/khao-sat/$code",
			params: { code },
			className: cn("mt-6 inline-flex min-h-11 items-center rounded-xl bg-emerald-700 px-4 text-sm font-semibold text-emerald-50"),
			children: "Gửi nhận thức"
		})
	] });
}
function SurveyPage() {
	const { code } = useParams({ strict: false });
	const profile = useVerdex((state) => state.profile);
	const addReview = useVerdex((state) => state.addReview);
	const [pack, setPack] = (0, import_react.useState)(3);
	const [ship, setShip] = (0, import_react.useState)(3);
	const [back, setBack] = (0, import_react.useState)(3);
	const [clear, setClear] = (0, import_react.useState)(3);
	const [sent, setSent] = (0, import_react.useState)("");
	const live = code === profile.code;
	const peer = PEERS.find((item) => item.code === code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl font-semibold tracking-tight",
			children: "Khảo sát nhận thức"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 max-w-2xl text-sm leading-6 text-slate-600",
			children: [live ? profile.name : peer?.name ?? "Hồ sơ", ". Thang 1 đến 5 được quy về 0–100. Một lượt không tự sửa Green Score."]
		}),
		!live && !peer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm",
			children: "Không thấy doanh nghiệp."
		}) : null,
		live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6 max-w-xl space-y-4 rounded-2xl border border-slate-200 bg-white p-5",
			onSubmit: (event) => {
				event.preventDefault();
				const aspects = [
					{
						id: "pack",
						score: pack
					},
					{
						id: "ship",
						score: ship
					},
					{
						id: "back",
						score: back
					},
					{
						id: "clear",
						score: clear
					}
				];
				const hundred = (aspects.reduce((sum, item) => sum + item.score, 0) / aspects.length - 1) / 4 * 100;
				const top = aspects.slice().sort((a, b) => b.score - a.score)[0];
				addReview(hundred, top?.id ?? "pack");
				setSent("Đã ghi một đánh giá hợp lệ vào hồ sơ thí điểm.");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale$1, {
					label: "Bao bì",
					value: pack,
					onChange: setPack
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale$1, {
					label: "Vận chuyển",
					value: ship,
					onChange: setShip
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale$1, {
					label: "Thu hồi",
					value: back,
					onChange: setBack
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale$1, {
					label: "Minh bạch",
					value: clear,
					onChange: setClear
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "min-h-11 rounded-xl bg-emerald-700 px-4 text-sm font-semibold text-emerald-50",
					children: "Gửi đánh giá"
				}),
				sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-slate-600",
					children: sent
				}) : null
			]
		}) : peer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm text-slate-600",
			children: [
				"Hồ sơ tĩnh không nhận khảo sát. Chỉ hồ sơ thí điểm ",
				profile.code,
				" cập nhật nhận thức."
			]
		}) : null
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-slate-200 bg-white p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-slate-500",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xl font-semibold",
			children: value
		})]
	});
}
function Scale$1({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm text-slate-700",
		children: [
			label,
			": ",
			value,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 1,
				max: 5,
				value,
				onChange: (event) => onChange(Number(event.target.value)),
				className: "mt-2 block w-full"
			})
		]
	});
}
//#endregion
export { ProfilePage as n, SurveyPage as r, HomePage as t };
