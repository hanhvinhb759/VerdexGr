import { r as SurveyPage } from "./_ssr/public-pages-DcZBMsfr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_code-CuaeqZ6V.js
var SplitComponent = SurveyPage;
//#endregion
export { SplitComponent as component };
