//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-jxQUgbPw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/chan-doan",
			"/dang-ky",
			"/dang-nhap",
			"/danh-gia-lai",
			"/goi-dich-vu",
			"/khoang-cach",
			"/khuyen-nghi",
			"/ma-tran",
			"/minh-bach",
			"/nhap-lieu",
			"/tong-quan",
			"/tru-van-hanh",
			"/doanh-nghiep/$code",
			"/khao-sat/$code"
		],
		preloads: ["/assets/index-1BOG_is5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-1BOG_is5.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BoUff8X2.js", "/assets/public-pages-Bb6kTtHU.js"]
	},
	"/chan-doan": {
		filePath: "/workspace/src/routes/chan-doan.tsx",
		children: void 0,
		preloads: [
			"/assets/chan-doan-CJECNOUa.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/intel-pages-Db-L-nqW.js"
		]
	},
	"/dang-ky": {
		filePath: "/workspace/src/routes/dang-ky.tsx",
		children: void 0,
		preloads: ["/assets/dang-ky-C2hG2h9v.js", "/assets/account-pages-j9FdTAVr.js"]
	},
	"/dang-nhap": {
		filePath: "/workspace/src/routes/dang-nhap.tsx",
		children: void 0,
		preloads: ["/assets/dang-nhap-AbQmm-Vu.js", "/assets/account-pages-j9FdTAVr.js"]
	},
	"/danh-gia-lai": {
		filePath: "/workspace/src/routes/danh-gia-lai.tsx",
		children: void 0,
		preloads: [
			"/assets/danh-gia-lai-BBEEe-D7.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/intel-pages-Db-L-nqW.js"
		]
	},
	"/goi-dich-vu": {
		filePath: "/workspace/src/routes/goi-dich-vu.tsx",
		children: void 0,
		preloads: ["/assets/goi-dich-vu-B5kRL3y7.js", "/assets/account-pages-j9FdTAVr.js"]
	},
	"/khoang-cach": {
		filePath: "/workspace/src/routes/khoang-cach.tsx",
		children: void 0,
		preloads: [
			"/assets/khoang-cach-DuP3GsFW.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/intel-pages-Db-L-nqW.js"
		]
	},
	"/khuyen-nghi": {
		filePath: "/workspace/src/routes/khuyen-nghi.tsx",
		children: void 0,
		preloads: [
			"/assets/khuyen-nghi-DG7gL4dn.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/intel-pages-Db-L-nqW.js"
		]
	},
	"/ma-tran": {
		filePath: "/workspace/src/routes/ma-tran.tsx",
		children: void 0,
		preloads: [
			"/assets/ma-tran-DlpZuTGJ.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/work-pages-ZbwusYHV.js"
		]
	},
	"/minh-bach": {
		filePath: "/workspace/src/routes/minh-bach.tsx",
		children: void 0,
		preloads: [
			"/assets/minh-bach-D-b2q0tM.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/work-pages-ZbwusYHV.js"
		]
	},
	"/nhap-lieu": {
		filePath: "/workspace/src/routes/nhap-lieu.tsx",
		children: void 0,
		preloads: [
			"/assets/nhap-lieu-DD65OjOz.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/work-pages-ZbwusYHV.js"
		]
	},
	"/tong-quan": {
		filePath: "/workspace/src/routes/tong-quan.tsx",
		children: void 0,
		preloads: [
			"/assets/tong-quan-B7tKBf2k.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/utils-DedHQe_0.js"
		]
	},
	"/tru-van-hanh": {
		filePath: "/workspace/src/routes/tru-van-hanh.tsx",
		children: void 0,
		preloads: [
			"/assets/tru-van-hanh-nlsyQrei.js",
			"/assets/enterprise-shell-Bbrfl55n.js",
			"/assets/work-pages-ZbwusYHV.js"
		]
	},
	"/doanh-nghiep/$code": {
		filePath: "/workspace/src/routes/doanh-nghiep/$code.tsx",
		children: void 0,
		preloads: ["/assets/_code-s6erPqvs.js", "/assets/public-pages-Bb6kTtHU.js"]
	},
	"/khao-sat/$code": {
		filePath: "/workspace/src/routes/khao-sat/$code.tsx",
		children: void 0,
		preloads: ["/assets/_code-Cl42j7Jf.js", "/assets/public-pages-Bb6kTtHU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
