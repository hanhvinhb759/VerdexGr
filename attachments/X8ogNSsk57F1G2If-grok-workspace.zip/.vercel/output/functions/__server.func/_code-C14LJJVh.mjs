import { n as ProfilePage } from "./_ssr/public-pages-DcZBMsfr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_code-C14LJJVh.js
var SplitComponent = ProfilePage;
//#endregion
export { SplitComponent as component };
